Rails.application.routes.draw do

    root 'boards#index'
    
    resources :boards do
      resources :songs
    end

  # For details on the DSL available within this file, see http://guides.rubyonrails.org/routing.html
end


# # This makes changing all parents easier
# concern :has_child do
#   resource :child
# end

# resources :first_parents, concerns: :has_child

# resources :second_parents, concerns: :has_child

# # Rails may be smart enough for us to use :children instead of :childs
# resources :children do
#   resource :first_parent
#   resource :second_parent
# end